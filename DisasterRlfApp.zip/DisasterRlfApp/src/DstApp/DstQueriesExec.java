package DstApp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



public class DstQueriesExec {
	
	private String[] empdtls;

	public int RegisterQuery(GetUserDtls registeruser) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = Connections.makeConnection();
		int i = 0;
		try {
			pstmt = conn.prepareStatement(DstQueries.RegUsrQry);

			pstmt.setString(1, registeruser.getFirst_name());
			pstmt.setString(2, registeruser.getMiddle_name());
			pstmt.setString(3, registeruser.getLast_name());
			pstmt.setString(4, registeruser.getAddress());
			pstmt.setString(5, registeruser.getEmail());
			pstmt.setString(6, registeruser.getCity());
			pstmt.setString(7, registeruser.getState());
			pstmt.setString(8, registeruser.getCounty());
			pstmt.setString(9, registeruser.getZipcode());
			pstmt.setString(10, registeruser.getPhonenumber());
			pstmt.setString(11, registeruser.getUsername());
			pstmt.setString(12, registeruser.getPassword());
			i = pstmt.executeUpdate();
			Connections.closeconnection(pstmt, conn);

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return i;
	}
	
	public List<GetApprDtls> ApplQuery() 
	
	{
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = Connections.makeConnection();
		 List<GetApprDtls> getallapps = new ArrayList<>();
		 ResultSet rs = null;
		
		 try {
			
			 pstmt = conn.prepareStatement(DstQueries.getallapps);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				
				GetApprDtls apps = new  GetApprDtls (rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5));		
				getallapps.add(apps);
			}

			
			
		} catch (Exception e) {
			e.printStackTrace();}

  return getallapps;
		
	}

	public List<GetApprDtls> ApplQuery(String userid) 
	
	{
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = Connections.makeConnection();
		 List<GetApprDtls> getallapps = new ArrayList<>();
		 ResultSet rs = null;
		
		 try {
			
			 pstmt = conn.prepareStatement(DstQueries.getusrapps);
			 pstmt.setString(1, userid);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				
				GetApprDtls apps = new  GetApprDtls (rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5));		
				getallapps.add(apps);
			}

			
			
		} catch (Exception e) {
			e.printStackTrace();}

  return getallapps;
		
	}
	
	
	
	public int checklogin(String id, String password) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = Connections.makeConnection();
		ResultSet rs = null;
		int i = 0;
		try {

			pstmt = conn.prepareStatement(DstQueries.logincheck);
			// pstmt.setString(1,password);
			pstmt.setString(1, id);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				i = rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return i;
	}
	
	
	
	public  String[] checklogin2(String id, String password) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = Connections.makeConnection();
		ResultSet rs = null;
		
		  String[] empdtls = new String[4];
		
		try {

			pstmt = conn.prepareStatement(DstQueries.logincheck2);
			// pstmt.setString(1,password);
			pstmt.setString(1, id);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				
				empdtls[0]="1";
				empdtls[1]=rs.getString(1);
				empdtls[2]=rs.getString(2);
				empdtls[3]=rs.getString(3);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return empdtls;
	}
	
	
	
	
	public  String[] ApplDtls (int appid) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = Connections.makeConnection();
		ResultSet rs = null;
		String[] appdtls = new String[7];
		
		try {

			pstmt = conn.prepareStatement(DstQueries.getlossapp);
			// pstmt.setString(1,password);
			pstmt.setInt(1, appid);
			
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				   
				appdtls[0]= String.valueOf(rs.getInt(1));
				appdtls[1]= rs.getString(2);
				appdtls[2]= rs.getString(3);
				appdtls[3]= rs.getString(4);
				appdtls[4]= String.valueOf(rs.getInt(5));
				appdtls[5]= String.valueOf(rs.getInt(6));
				appdtls[6]= rs.getString(7); 
			
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return appdtls;
	}
	
	
	
	/*public  ArrayList<String[]>  ApplDtls (String custname, String state, String county) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = Connections.makeConnection();
		ResultSet rs = null;
		int count = 0;
		//String[] appdtls = new String[count];
		ArrayList<String[]> appdtls = new ArrayList();

		try {

			pstmt = conn.prepareStatement(DstQueries.getlossapp);
			// pstmt.setString(1,password);
			pstmt.setString(1, custname);
			pstmt.setString(2, state);
			pstmt.setString(3, county);
			
			rs = pstmt.executeQuery();
			count = rs.getMetaData().getColumnCount(); 
			String[] currentRow = new String[count];
			
			while (rs.next()) {
				   
				 for(int i = 1;i<=count;i++)
				 {
					 currentRow[i-1]=rs.getString(i);
			        }
				 
				 appdtls.add(currentRow);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return appdtls;
	}*/
	
	
    public List<String> loadState() {

		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = Connections.makeConnection();
		ResultSet rs = null;
		
        List<String> stlist = new ArrayList <String>();
		
        try {
        	pstmt = conn.prepareStatement(DstQueries.getstate);
        	rs = pstmt.executeQuery();
        	
        	while (rs.next()) {
        		stlist.add(rs.getString(1));
			}
        	
        	
        } catch (Exception e) {
			e.printStackTrace();
        }
        
        return stlist ;
        
        };
        
        
        public List<String> loadCounty(String statenm) {

    		Connection conn = null;
    		PreparedStatement pstmt = null;
    		conn = Connections.makeConnection();
    		ResultSet rs = null;
    		
            List<String> cntylist = new ArrayList <String>();
    		
            try {
            	pstmt = conn.prepareStatement(DstQueries.getcnty);
            	pstmt.setString(1, statenm);
    			rs = pstmt.executeQuery();
            	
            	while (rs.next()) {
            		cntylist.add(rs.getString(1));
    			}
            	
            	
            } catch (Exception e) {
    			e.printStackTrace();
            }
            
            return cntylist ;
            
            };
            
        
        public List<HashMap<String,String>> loadStatehash() {

    		Connection conn = null;
    		PreparedStatement pstmt = null;
    		conn = Connections.makeConnection();
    		ResultSet rs = null;
    		
    		 List<HashMap<String,String>> stcntys = new ArrayList<HashMap<String,String>>(); 
    		 
    	
            try {
            	pstmt = conn.prepareStatement(DstQueries.getstatecnty);
            	rs = pstmt.executeQuery();
            	
            	while (rs.next()) {
            	
            		 HashMap<String,String> row = new HashMap<String, String> ();
            		 
            		 row.put(rs.getString(1),rs.getString(2));
            		 stcntys.add(row);
    			}
            	
            	
            } catch (Exception e) {
    			e.printStackTrace();
            }
            
            return stcntys;
            
            };
            
           /* public ListMultimap<String, String> loadStatehashh() {

        		Connection conn = null;
        		PreparedStatement pstmt = null;
        		conn = Connections.makeConnection();
        		ResultSet rs = null;
        		
        		 //HashMap<String, ArrayList<String>> stcntys = new HashMap<String, ArrayList<String>>();
        		 
        		 //ArrayList<String> states = new ArrayList<String>();
        		 
        		 ListMultimap<String, String> stcntys = ArrayListMultimap.create();
        	
                try {
                	pstmt = conn.prepareStatement(DstQueries.getstatecnty);
                	rs = pstmt.executeQuery();
                	
                	while (rs.next()) {
                		
                		stcntys.put(rs.getString(1),rs.getString(2));

        			}
                	
                	
                } catch (Exception e) {
        			e.printStackTrace();
                }
                
                return stcntys;
                
                };*/
                
                public HashMap<String, ArrayList<String>>  loadStatehashmap() {

            		Connection conn = null;
            		PreparedStatement pstmt = null;
            		conn = Connections.makeConnection();
            		ResultSet rs = null;
            		
            		 HashMap<String, ArrayList<String>> stcntys = new HashMap<String, ArrayList<String>>();
            		 
            		 //ArrayList<String> states = new ArrayList<String>();
            	
                    try {
                    	pstmt = conn.prepareStatement(DstQueries.getstatecnty);
                    	rs = pstmt.executeQuery();
                    	
                    	while (rs.next()) {
                    		
                    		String key = rs.getString(1);
                    		String value = rs.getString(2).trim();
                    		
                    		if (stcntys.get(key) == null)
                    			stcntys.put(key,  new ArrayList<>());

                    		stcntys.get(key).add(value);

            			}
                    	
                    	
                    } catch (Exception e) {
            			e.printStackTrace();
                    }
                    
                    return stcntys;
                    
                    };
                    
                    
               
                    
                	public void UpdApplSts(String status, int aprvdamt, int id ) {
                		Connection conn = null;
                		PreparedStatement pstmt = null;
                		conn = Connections.makeConnection();

                		try {
                			pstmt = conn.prepareStatement(DstQueries.UpdAppsts);
                			
                			pstmt.setString(1, status);
                			pstmt.setInt(2,aprvdamt);
                			pstmt.setInt(3,id);
                			pstmt.executeUpdate();
                			// conn.commit();
                		} catch (Exception e) {
                			e.printStackTrace();
                		}
                	}
                	
                	
                	public int resetPswd(ResetPwdUtil rstpwd) throws ParseException
                    {
                        Connection conn = null;
                        PreparedStatement pstmt = null;
                        conn = Connections.makeConnection();
                       // boolean i = false;
                        int i = 0;
                        try
                        {
                            System.out.println(rstpwd.getPswd());
                            System.out.println(rstpwd.getUser());
                            pstmt = conn.prepareStatement(DstQueries.ResetPwd);
                           pstmt.setString(1,rstpwd.getPswd());
                           pstmt.setString(2,rstpwd.getUser());
                          
                           //System.out.println(pstmt.);
                                                      
                            i = pstmt.executeUpdate();                       
                            System.out.println("Updated"+i);
                            Connections.closeconnection(pstmt, conn);
               
                        } catch (SQLException  e) {e.printStackTrace();
                       
                        return i;
                        }
                        return i;
                    }
                	
                	 public List<String> loadcmdty_to_userpage() {

                		 

                         Connection conn = null;
                         PreparedStatement pstmt = null;
                         conn = Connections.makeConnection();
                         ResultSet rs = null;
                         
                         List<String> cmdtylist = new ArrayList <String>();
                         
                         try {
                             pstmt = conn.prepareStatement(DstQueries.getcmdty);
                             rs = pstmt.executeQuery();
                             
                             while (rs.next()) {
                                 cmdtylist.add(rs.getString(1).trim());
                                 //System.out.println(rs);
                             }
                             
                             
                         } catch (Exception e) {
                             e.printStackTrace();
                         }
                         
                         System.out.println("get cmdty succssfull");
                         
                         return cmdtylist ;
                         
                         }
                	 
                	 
                	 
                	 // ----- map tp get commodity and  UOM ------//
                     
                              
                     public HashMap<String, ArrayList<String>>  cmdtyUomhashmap() {

         

                            Connection conn = null;
                            PreparedStatement pstmt = null;
                            conn = Connections.makeConnection();
                            ResultSet rs = null;
                            
                             HashMap<String, ArrayList<String>> cmdtyUom = new HashMap<String, ArrayList<String>>();
                             
                             //ArrayList<String> states = new ArrayList<String>();
                        
                            try {
                                pstmt = conn.prepareStatement(DstQueries.getcmdtyUom);
                                rs = pstmt.executeQuery();
                                int i = 0;
                                
                                while (rs.next()) {
                                    
                                    String key = rs.getString(1).trim();
                                    String value = rs.getString(2).trim();
                                    
                                    if (cmdtyUom.get(key) == null)
                                        cmdtyUom.put(key,  new ArrayList<>());

         

                                    cmdtyUom.get(key).add(value);
                              i+=1;
                                }
                                
                                System.out.println(i);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            
                            System.out.println("returing the map now");
                            return cmdtyUom;
                            
                            }   	
  
                     public int DstrEntry(DisasterCreate dstrEntry) throws ParseException
                     {
                         Connection conn = null;
                         PreparedStatement pstmt = null;
                         conn = Connections.makeConnection();
                         int i = 0;
                         try
                         {
                             pstmt = conn.prepareStatement(DstQueries.DsEntryQry);
                            
                             pstmt.setInt(1,dstrEntry.get_DstrCode());
                             pstmt.setString(2,dstrEntry.get_State());
                             pstmt.setString(3,dstrEntry.get_Cnty());
                             pstmt.setString(4,dstrEntry.get_DstrName());
                             pstmt.setString(5,dstrEntry.get_Dstrtype());                       
                             pstmt.setDate(6,dstrEntry.get_startDte());
                             pstmt.setDate(7,dstrEntry.get_endDte());
                             i = pstmt.executeUpdate();
                             System.out.println("Inserted"+i);
                             Connections.closeconnection(pstmt, conn);
                
                         } catch (SQLException | ParseException e) {e.printStackTrace();
                         }
                         return i;
                        
                     }
                     
                     public int ApplEntry(CrtDisAppl  applEntry)
                     {
                         Connection conn = null;
                         PreparedStatement pstmt = null;
                         conn = Connections.makeConnection();
                         int i = 0;
                         try
                         {
                             pstmt = conn.prepareStatement(DstQueries.AplInstQry);
                             
                             
                             pstmt.setString(1,applEntry.get_custName());
                             pstmt.setString(2,applEntry.get_stateName());
                             pstmt.setString(3,applEntry.get_cntyName());
                             pstmt.setString(4,applEntry.get_dstrType());
                             pstmt.setString(5,applEntry.get_cmdty());
                             pstmt.setInt(6,applEntry.get_lossQty());
                             pstmt.setDouble(7,applEntry.get_claimAmt());
                             pstmt.setInt(8,applEntry.get_aprvdAmt());
                             pstmt.setString(9,applEntry.get_uOM());
                             pstmt.setString(10,"Submitted");
                             pstmt.setInt(11,applEntry.get_Appl_id());
                             
                             i = pstmt.executeUpdate();
                             System.out.println("Inserted"+i);
                             Connections.closeconnection(pstmt, conn);

                         } catch (SQLException e) {

                             e.printStackTrace();
                         }
                         return i;                         
                     }
                     
                     
                     public List<String> loadDstr_to_userpage(String state, String county) { 


                         Connection conn = null;
                         PreparedStatement pstmt = null;
                         conn = Connections.makeConnection();
                         ResultSet rs = null;
                         
                         System.out.println("values in qry -exec"+state+county);
                         
                         List<String> dstrlist = new ArrayList <String>();
                         
                         try {
                             pstmt = conn.prepareStatement(DstQueries.getdstr);
                             pstmt.setString(1, state);
                             pstmt.setString(2, county);
                             rs = pstmt.executeQuery();
                             
                             while (rs.next()) {
                                 dstrlist.add(rs.getString(1));
                                 
                                System.out.println(rs.getString(1));
                                 
                             }
                             
                             
                         } catch (Exception e) {
                             e.printStackTrace();
                         }
                         System.out.println("in the query");
                         return dstrlist ;
                         
                         }
                     
                     
                     public int userValidation(String user)
                     {
                         Connection conn = null;
                         PreparedStatement pstmt = null;
                         conn = Connections.makeConnection();
                         ResultSet rs = null;
                        
                         int count = 0;
                        
                         try
                         {
                             pstmt=conn.prepareStatement(DstQueries.userchk);
                             pstmt.setString(1, user.trim());
                             rs=pstmt.executeQuery();
                             
                             while (rs.next()) {
                            	    count = rs.getInt(1);
                             }

                         
                           
                         }catch ( SQLException e) {e.printStackTrace();
                        
                     }
                        return count;
                       
                     }
    }
