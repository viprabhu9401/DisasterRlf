package DstApp;

public class GetApprDtls {

	private String  customer_name;
	private String  state_name;
	private String  county_name;
	private Integer  id;
	private String appstatus;
	public GetApprDtls(String customer_name, String state_name, String county_name, Integer id, String appstatus) {
		super();
		this.customer_name = customer_name;
		this.state_name = state_name;
		this.county_name = county_name;
		this.id = id;
		this.appstatus = appstatus;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getState_name() {
		return state_name;
	}
	public void setState_name(String state_name) {
		this.state_name = state_name;
	}
	public String getCounty_name() {
		return county_name;
	}
	public void setCounty_name(String county_name) {
		this.county_name = county_name;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAppstatus() {
		return appstatus;
	}
	public void setAppstatus(String appstatus) {
		this.appstatus = appstatus;
	}
	



	
	
	
}
