package DstApp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;





@WebServlet("/DisasterHomePage")

public class DisastLoginSrvlt extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisastLoginSrvlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
  
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id=request.getParameter("userid");
		String password=request.getParameter("password");
		String role=request.getParameter("Role");
		DstQueriesExec QE=new DstQueriesExec();
		
	    HttpSession httpSession = request.getSession();
        httpSession.setAttribute("name",id);
		
		
		 Cookie oldcookie = new Cookie("userid", "");
	        oldcookie.setMaxAge(0);
		
		Cookie loginCookie = new Cookie("userid",id);
		
		//setting cookie to expiry in 30 mins
		loginCookie.setMaxAge(4*60);
		response.addCookie(loginCookie);
		
		
		
		if(request.getParameter("Role").equals("Administrator"))
		{
			if(id.equals("admin")&&password.equals("password"))
			{
				
				RequestDispatcher rd=request.getRequestDispatcher("/JSP/DisasterAdmin.jsp");
				rd.forward(request,response);
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("/JSP/DisasterHomePage.jsp");
				rd.forward(request,response);
			}
		}
			else if(request.getParameter("Role").equals("Farmer-Rancher"))
			{
	
			String[] check=QE.checklogin2(id, password);
			
			if(check[0]=="1")
			{
				
				//Newly Added
				request.setAttribute("custname",check[1]);
				request.setAttribute("stname",check[2]);
				request.setAttribute("cntyname",check[3]);

				
				RequestDispatcher rd=request.getRequestDispatcher("/JSP/DisasterUserPage.jsp");
				rd.forward(request,response);
			}
			else
			{
				//JOptionPane.showMessageDialog( null, "Please enter valid id and password","Unable to login",JOptionPane.PLAIN_MESSAGE);
				PrintWriter out= response.getWriter();
				out.println("<font color=red>Either user name or password is wrong.</font>");
				RequestDispatcher rd=request.getRequestDispatcher("/JSP/DisasterHomePage.jsp");
				rd.forward(request,response);
			}
			
			}
		
		Cookie[] cookies = request.getCookies();
		int i = 0;
		for (Cookie cookie : cookies ) {

		  System.out.println(cookies[i].getName());
		  System.out.println(cookies[i].getValue());

		  i++;
		}
    }
}