package DstApp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisasterApplsrvlt
 */
@WebServlet("/DisasterApplsrvlt")
public class DisasterApplsrvlt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisasterApplsrvlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
     
		
    CrtDisAppl applEntry = new CrtDisAppl();
    
      String appl_id = request.getParameter("AppL_id");
       
       int Appl_Id =  Integer.parseInt(appl_id.trim());
		System.out.println(Appl_Id);
		
        applEntry.set_Appl_id(request.getParameter("AppL_id"));
        applEntry.set_custName(request.getParameter("cust_name"));
		applEntry.set_stateName(request.getParameter("State"));
		applEntry.set_cntyName(request.getParameter("County"));
		applEntry.set_dstrType(request.getParameter("SelectDstr"));
		applEntry.set_cmdty(request.getParameter("commodity"));
		applEntry.set_lossQty(request.getParameter("LossQ"));
		applEntry.set_claimAmt(request.getParameter("claimAmt"));
		applEntry.set_aprvdAmt(request.getParameter("ApprAmt"));
		applEntry.set_uOM(request.getParameter("UnitM"));
		applEntry.set_appStatus(request.getParameter("ApplStatus")); 
       
       /*System.out.println(request.getParameter("AppL_id"));
       System.out.println(request.getParameter("cust_name"));
       System.out.println(request.getParameter("State"));
       System.out.println(request.getParameter("County"));
       System.out.println(request.getParameter("SelectDstr"));
       System.out.println(request.getParameter("commodity"));
       System.out.println(request.getParameter("LossQ"));
       System.out.println(request.getParameter("claimAmt"));
       System.out.println(request.getParameter("ApprAmt"));
       System.out.println(request.getParameter("UnitM"));
       System.out.println(request.getParameter("ApplStatus"));*/
       
    
		DstQueriesExec QE=new DstQueriesExec();
		int i=QE.ApplEntry(applEntry);
		//System.out.println(i);
	   
		if(i==1)
		{
			//JOptionPane.showMessageDialog(null, "User Registraion Sucessfull");
		    //System.out.println("Going to Query now");  
			
			response.setContentType("text/html");
		    PrintWriter out = response.getWriter();
			out.println("<html><body><script>alert('Application Saved Sucessfully !!!');"
					+ "window.history.go(-2);"
					+ "</script></body></html>");
		    
		    
		    /*RequestDispatcher dispatcher = request.getRequestDispatcher("JSP/DisasterUserPage.jsp");
	           dispatcher.forward(request, response);*/
		}
		else
		{
			System.out.println("Query not executed");
		} 
		 
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	

}
