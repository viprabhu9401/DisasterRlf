package DstApp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





@WebServlet("/DisasterAppUpdate")

public class DisastAppUpdSrvlt extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisastAppUpdSrvlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
  
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	int appid= Integer.parseInt(request.getParameter("appid"));
	  String appstats=request.getParameter("status");
	  String appamtstrng = request.getParameter("AppAmt");
	  int appamt= Integer.parseInt(appamtstrng.trim());
	   
	 
	  
	  
	DstQueriesExec QE=new DstQueriesExec();
		QE.UpdApplSts(appstats,appamt,appid);
				
		
		response.setContentType("text/html");
	    PrintWriter out = response.getWriter();
		out.println("<html><body><script>alert('Application Status Saved Sucessfully !!!');"
				+ "window.history.go(-2);"
				+ "</script></body></html>");
		
				/*RequestDispatcher rd=request.getRequestDispatcher("/JSP/DiastshowallApps.jsp");
				rd.forward(request,response);*/
			}
   
    
}