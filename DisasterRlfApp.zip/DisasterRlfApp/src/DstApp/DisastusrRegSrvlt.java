package DstApp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





@WebServlet("/DisasterUserReg")

public class DisastusrRegSrvlt extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private DstQueriesExec stquery = new DstQueriesExec ();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisastusrRegSrvlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
  
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		GetUserDtls registeruser=new GetUserDtls();
	
		System.out.println(request.getParameter("Fname"));
		
		registeruser.setFirst_name(request.getParameter("Fname").trim());
		registeruser.setMiddle_name(request.getParameter("Mname").trim());
		registeruser.setLast_name(request.getParameter("Lname").trim());

		registeruser.setEmail(request.getParameter("email"));
		registeruser.setAddress(request.getParameter("Addr1"));
		registeruser.setCity(request.getParameter("City"));
		registeruser.setZipcode(request.getParameter("Zip"));
		registeruser.setUsername(request.getParameter("Username"));
		registeruser.setPhonenumber(request.getParameter("phonenum"));
		registeruser.setState(request.getParameter("State").trim());
		registeruser.setCounty(request.getParameter("Cnty").trim());
		registeruser.setPassword(request.getParameter("passwd"));
		
		
		DstQueriesExec QE=new DstQueriesExec();
		int i=QE.RegisterQuery(registeruser);
		
		
    	/*List<HashMap<String,String>> stcntys = stquery.loadStatehash();
			System.out.println(stcntys);
			request.setAttribute("Stcntysname",stcntys);*/
		
	  	/*ListMultimap<String,String> stcntys = stquery.loadStatehashh();
				System.out.println(stcntys);
				request.setAttribute("Stcntysname",stcntys);*/
		
		if(i==1)
		{
			//JFrame frame = new JFrame();
			//JOptionPane.showMessageDialog(frame, "User Registraion Sucessfull");
			response.setContentType("text/html");
		    PrintWriter out = response.getWriter();
			out.println("<html><body><script>alert('Registarion Sucessfull !!! Going back to LogIn Page');"
					+ "window.location = \"http://localhost:8080/DisasterRlfApp/JSP/DisasterHomePage.jsp\";"
					+ "</script></body></html>");
			 
		      /*RequestDispatcher dispatcher = request.getRequestDispatcher("JSP/DisasterHomePage.jsp");
	           dispatcher.forward(request, response);*/
		}
		else
		{
			
			//Add Error Message
			 RequestDispatcher dispatcher = request.getRequestDispatcher("JSP/DisasterHomePage.jsp");
			 dispatcher.forward(request, response);
			System.out.println("Query not executed");
		}
		
		}
			

}