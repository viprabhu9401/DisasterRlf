package DstApp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NewApplLoad
 */
@WebServlet("/NewApplLoad")
public class NewApplLoad extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	 DstQueriesExec dstrQry  = new DstQueriesExec ();
    public NewApplLoad() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// TODO Auto-generated method stub
		
		
		String custname=request.getParameter("custname");
   	    String state=request.getParameter("state").trim();
		String cnty=request.getParameter("county").trim();
		
		System.out.println(state + cnty);
		
		request.setAttribute("custname",custname.trim());
		request.setAttribute("stname",state.trim());
		request.setAttribute("cntyname",cnty);
		
		List <String> dstrlist = dstrQry.loadDstr_to_userpage(state,cnty);
		request.setAttribute("DstName",dstrlist );
		
		System.out.println("getting cmdty now");
		
		List <String> cmdtylist = dstrQry.loadcmdty_to_userpage();
		request.setAttribute("Cmdtylst", cmdtylist);
		
		//  sending the map to JSP page //
		HashMap<String, ArrayList<String>>  cmdtyUom =  dstrQry.cmdtyUomhashmap();
		request.setAttribute("CmdtyUomMap",cmdtyUom);
		
		
		
		//System.out.println(cmdtylist);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("JSP/DisasterApplPg.jsp");
        dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	

}
