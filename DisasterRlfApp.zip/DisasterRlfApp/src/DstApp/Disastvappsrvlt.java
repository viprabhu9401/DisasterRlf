package DstApp;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/DisastervappPage")

public class Disastvappsrvlt extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Disastvappsrvlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
  
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
    	 /*HttpSession session=request.getSession(true);*/
    	 
    	 String custname=request.getParameter("custname");
    	 String state=request.getParameter("stname");
 		String cnty=request.getParameter("cntyname");
 		
    	int appid= Integer.parseInt(request.getParameter("appid"));
		
    	//String state=request.getParameter("state");
		//String cnty=request.getParameter("county");
		
		//request.setAttribute("appid", custname);
		
		DstQueriesExec QE=new DstQueriesExec();
		
		String[] appdtls=QE.ApplDtls(appid);
		
				request.setAttribute("appid", appdtls[0]);
				request.setAttribute("custname", custname);
				request.setAttribute("stname", state);
				request.setAttribute("cntyname", cnty);
				request.setAttribute("disastyp",appdtls[1]);
				request.setAttribute("cmdyname",appdtls[2]);
				request.setAttribute("lossqty",appdtls[3]);
				request.setAttribute("lossamt",appdtls[4]);
				request.setAttribute("apprvdamt",appdtls[5]);
				request.setAttribute("appstatus",appdtls[6]);
				
				
				
				RequestDispatcher rd=request.getRequestDispatcher("/JSP/DisasterViewApp.jsp");
				rd.forward(request,response);
			}
		
}