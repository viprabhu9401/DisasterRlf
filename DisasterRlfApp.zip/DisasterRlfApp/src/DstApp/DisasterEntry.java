package DstApp;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisasterEntry
 */
@WebServlet("/DisasterEntry")
public class DisasterEntry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisasterEntry() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		//SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd-yyyy");
		
		
		DisasterCreate dstrEntry = new DisasterCreate();
		
		dstrEntry.set_DstrName(request.getParameter("dstr-name"));
		dstrEntry.set_DstrCode(request.getParameter("dstr_cde"));
		dstrEntry.set_Dstrtype(request.getParameter("dstr_type"));
		dstrEntry.set_State(request.getParameter("State").trim());
		dstrEntry.set_Cnty(request.getParameter("County").trim());
		dstrEntry.set_StrtDte(request.getParameter("strt_date"));
		dstrEntry.set_endtDte(request.getParameter("end_date"));
		
		//try {
			
	
		//Date startDate = simpleDateFormat.parse(request.getParameter("DR-STRT"));
		//Date endDate;
	
			//endDate = simpleDateFormat.parse(request.getParameter("DR-END"));
			//	dstrEntry.set_StrtDte(startDate);
				//dstrEntry.set_endtDte(endDate);
				
				
		
		//dstrEntry.set_State(request.getParameter("DR-END"));
		
		//System.out.println(startDate);
		//System.out.println(endDate);
		
		System.out.println(request.getParameter("dstr-name"));
	   System.out.println(request.getParameter("dstr_cde"));
	   System.out.println(request.getParameter("dstr_type"));
	   System.out.println(request.getParameter("strt_date"));
	   System.out.println(request.getParameter("end_date"));
	   
	   
	  		//String startDate = request.getParameter("DR-STRT");
		//String endDate=request.getParameter("DR-END");
		//PrintWriter out = response.getWriter();
				//out.println(request.getParameter("DR-STRT")+"\n");
				//out.println(request.getParameter("DR-END")+"\n");
	
	   //out.println("Hello world"+"\n");
		
		///} catch (ParseException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		//}*/
		
   
		DstQueriesExec QE=new DstQueriesExec();
		
		int i = 0;
		try {
			i = QE.DstrEntry(dstrEntry);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(i);
	   
		if(i==1)
		{
			
			  response.setContentType("text/html");
	            PrintWriter out = response.getWriter();
	            out.println("<html><body><script>alert('Disaster event added Sucessfully!');"
	                    + "window.location = \"http://localhost:8080/DisasterRlfApp/JSP/DisasterAdmin.jsp\";"
	                    + "</script></body></html>");
		}
		else
		{
			System.out.println("Query not executed");
		}       
				
	   
	   
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	

}
