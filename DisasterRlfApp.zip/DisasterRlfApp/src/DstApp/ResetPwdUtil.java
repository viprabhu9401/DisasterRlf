package DstApp;

public class ResetPwdUtil {

	private String user_name;
	private String Password;
	
	public void setUser(String user_name) {
		this.user_name=user_name;
	}
	
	public String getUser()
	{
		return user_name;
	}
	
	public void setPswd(String Password)
	{
		this.Password = Password;
	}
	
	public String getPswd() {
		return Password;
	}
	
}
