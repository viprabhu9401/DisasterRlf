package DstApp;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DstAppUsrdtls {

	
	private String FirstName;
	private String MiddleName;
	private String LastName;
	private String Gender;
	private String password;
	private String DOJ;
	private String Email;
	private String Address;
	

	private long ContactNumber;
	private String Designation;
	private String Status;
	
	private String DOT;
	private String ReasonOfSeperation;
	public void setAllEmployeeDetails(ResultSet rs) throws SQLException
	{
		/*while(rs.next())
		{
			StudentId=rs.getInt(1);
			password=rs.getString(2);
			FirstName=rs.getString(3);
			LastName=rs.getString(4);
			Email=rs.getString(5);
			Designation=rs.getString(6);
			DOJ=rs.getString(7);
			Gender=rs.getString(8);
			Address=rs.getString(9);
			MiddleName=rs.getString(10);
			Status=rs.getString(11);
			DOT=rs.getString(12);
			ReasonOfSeperation=rs.getString(13);
			ContactNumber=rs.getLong(14);
		}*/
	}
	/*public long getStudentId() {
		return StudentId;
	}
	public void setEmpId(long EmpId) {
		this.StudentId = EmpId;
	}*/
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getMiddleName() {
		return MiddleName;
	}
	public void setMiddleName(String middleName) {
		MiddleName = middleName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getDOJ() {
		return DOJ;
	}
	public void setDOJ(String dOJ) {
		DOJ = dOJ;
	}

	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public long getContactNumber() {
		return ContactNumber;
	}
	public void setContactNumber(long d) {
		ContactNumber = d;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getDOT() {
		return DOT;
	}
	public void setDOT(String DOT) {
		this.DOT = DOT;
	}
	public String getReasonOfSeperation() {
		return ReasonOfSeperation;
	}
	public void setReasonOfSeperation(String reasonOfSeperation) {
		ReasonOfSeperation = reasonOfSeperation;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	}


	
