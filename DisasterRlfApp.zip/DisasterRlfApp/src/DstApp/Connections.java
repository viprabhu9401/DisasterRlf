package DstApp;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Connections {
	static String url = "jdbc:oracle:thin:@fsadbmd0011.edc.ds1.usda.gov:1521:fsaedwd";
	static String username="u_mastan_madina";
	static String pwd ="Cht_iit04082020";
String Query="";

public Statement stmt;
public ResultSet rs;

/*jdbc:oracle:thin:@localhost:3306:roseindia",
"root", "root");*/

	
public  static Connection makeConnection() 
{
	
	
	Connection connection=null;
	try {
		
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		connection=DriverManager.getConnection(url,username,pwd);
		 System.out.println("SUCCESS");
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return connection;
}
public static void closeconnection(PreparedStatement pstmt,Connection conn)

{
try
{
	if(null!=conn)
	{
		conn.close();
	}
	if(null!=pstmt)
	{
		pstmt.close();
	}
}
catch(SQLException e)
{
	e.printStackTrace();
}
}
public static void closeconnection(PreparedStatement pstmt,Connection conn,ResultSet rs)
{
	try
	{
		if(null!=conn)
		{
			conn.close();
		}
		if(null!=pstmt)
		{
			pstmt.close();
		}
		if(null!=rs)
		{
			rs.close();
		}
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
}
}
