package DstApp;

public class DstQueries {
	

	//Disaster APP
	public static String logincheck="select count(*) from JAVA_PROJ_USERS where USER_NAME=? and PASSWORD=?";
	public static String logincheck2="select FIRST_NAME ||' '|| MIDDLE_NAME ||' '||LAST_NAME as  NAME,STATE,COUNTY from JAVA_PROJ_USERS where USER_NAME=? and PASSWORD=?";
	public static String getstate="select DISTINCT STATE_NAME from JAVA_PROJ_ST_CNTY ORDER BY STATE_NAME ";
	public static String getcnty="select DISTINCT COUNTY_NAME from JAVA_PROJ_ST_CNTY WHERE STATE_NAME= ? ORDER BY COUNTY_NAME";
	
	public static String RegUsrQry=" insert into JAVA_PROJ_USERS(FIRST_NAME,MIDDLE_NAME,LAST_NAME,ADDRESS1,EMAIL,"
																		+ "CITY,STATE,COUNTY,ZIP_CD,PHONE_NUMBER,USER_NAME,"
																		+ "PASSWORD)values"
																		+ "(?,?,?,?,?,?,?,?,?,?,?,?)" ;
	
	public static String getstatecnty="select DISTINCT STATE_NAME,COUNTY_NAME from JAVA_PROJ_ST_CNTY ORDER BY COUNTY_NAME ";


public static String getlossapp= "SELECT APPL_ID,DISASTER_TYPE,COMMODITY_NAME,LOSS_QUANTITY ||' '|| UOM AS LOSS_QUANTITY,EST_LOSS_AMOUNT,APPROVED_LOSS_AMOUNT,"
		+ "APP_STATUS FROM JAVA_PROJ_LOSSAPP WHERE APPL_ID=?";

public static String getallapps= "SELECT CUSTOMER_NAME, STATE_NAME, COUNTY_NAME,APPL_ID,APP_STATUS FROM JAVA_PROJ_LOSSAPP WHERE APP_STATUS='Submitted'";

public static String getusrapps= "SELECT CUSTOMER_NAME, STATE_NAME, COUNTY_NAME,APPL_ID,APP_STATUS FROM JAVA_PROJ_LOSSAPP WHERE CUSTOMER_NAME IN (Select FIRST_NAME ||' '|| MIDDLE_NAME ||' '||LAST_NAME FROM  JAVA_PROJ_USERS WHERE USER_NAME=?)";

public static String UpdAppsts="update JAVA_PROJ_LOSSAPP set APP_STATUS=?,APPROVED_LOSS_AMOUNT=? where APPL_ID=?";

public static String ResetPwd = "update JAVA_PROJ_USERS set PASSWORD = ? where USER_NAME =?";

public static String AplInstQry = "insert into JAVA_PROJ_LOSSAPP ( customer_name, state_name,"
        +"county_name,DISASTER_TYPE,commodity_name,"
       +"loss_quantity,"
        +"est_loss_amount,approved_loss_amount,"
         +"uom,app_status,APPL_ID)VALUES"
          +"(?,?,?,?,?,?,?,?,?,?,?)";

public static String DsEntryQry = "insert into JAVA_PROJ_DISASTER(DISASTER_CODE,STATE_NAME,COUNTY_NAME,"
        + "DISASTER_NAME,DISASTER_TYPE,DISASTER_START_DATE, DISASTER_END_DATE)values"
        + " (?,?,?,?,?,?,?)";

public static String getcmdtyUom = "select COMMODITY_NAME,UOM FROM JAVA_PROJ_COMMODITY where COMMODITY_NAME in "
        + "(select distinct commodity_name from java_proj_commodity "
        + " order by commodity_name  fetch first 19 rows ONLY)";

public static String getcmdty="select distinct commodity_name from java_proj_commodity order by commodity_name  fetch first 19 rows ONLY ";


public static String getdstr="select DISASTER_NAME ||' '|| DISASTER_TYPE  as disaster from java_proj_disaster where STATE_NAME=? and county_name=? and disaster_start_date < sysdate  and disaster_end_date > sysdate";

public static String userchk="select count(*) from JAVA_PROJ_USERS where USER_NAME=?";


}
