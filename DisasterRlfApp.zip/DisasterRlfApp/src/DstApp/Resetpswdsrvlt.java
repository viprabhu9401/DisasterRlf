package DstApp;

import java.io.IOException;
import javax.servlet.http.*;
import java.io.PrintWriter;
import java.text.ParseException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import javax.servlet.http.Cookie;

/**
 * Servlet implementation class Resetpswdsrvlt
 */
@WebServlet("/Resetpswdsrvlt")
public class Resetpswdsrvlt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Resetpswdsrvlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 * 
	 * 
	 * 
	 */
    
   
    
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	
		HttpSession session = request.getSession();
	    
	  
	    Cookie[] cookies = request.getCookies();
		int n = 0;
		   String sessionUser = null;
		      
		   
		   for (@SuppressWarnings("unused") Cookie cookie : cookies ) {

		        if ( ( (cookies[n].getName())!=null) && ( cookies[n].getName().equalsIgnoreCase("userid")))
			        sessionUser = cookies[n].getValue();
               			
			             System.out.println(cookies[n].getName());
		                      System.out.println(cookies[n].getValue());

		  n++;
		}
	 
	  System.out.println("session user is "+sessionUser);
	  
	  
	
		
		
		String Error = "Password Reset Unsuccessfull";
	        request.setAttribute("SYS-MESSAGE", Error);
	
		
		String user = request.getParameter("user-id");
		    String psswd = request.getParameter("password2");
		
		System.out.println("user"+user+" passed "+psswd);
		
		 
		
		ResetPwdUtil  RstPwd = new ResetPwdUtil();
		
		RstPwd.setUser(user);
		RstPwd.setPswd(psswd);
		
		DstQueriesExec QE=new DstQueriesExec();
		
		
		
	
		int count = QE.userValidation(user.trim());
		
		
		if (count == 0)
		{
			 System.out.println("Going to Execute user validation Query now");
	            
			
				 response.setContentType("text/html");
				      PrintWriter out = response.getWriter();
	                       out.println("<html><body><script>alert('Please Enter a valid  user Name!');"
	                           + "window.location = \"http://localhost:8080/DisasterRlfApp/JSP/ResetPasswd.jsp\";"
	                                + "</script></body></html>");
	            
		}
		
		else
		{
	             int i = 0;
		try {
			i = QE.resetPswd(RstPwd);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		            System.out.println(i);
	
		if(i==1)
		{
			
			if (sessionUser=="admin")
			{
			System.out.println("Going to Execute Query now");
	            response.setContentType("text/html");
	            PrintWriter out = response.getWriter();
	            out.println("<html><body><script>alert('Password reset was SUcessfull!');"
	                    + "window.location = \"http://localhost:8080/DisasterRlfApp/JSP/DisasterAdmin.jsp\";"
	                    + "</script></body></html>");  }
			
			else {
				
				response.setContentType("text/html");
	            PrintWriter out = response.getWriter();
	            out.println("<html><body><script>alert('Password reset was SUcessfull!');"
	                    + "window.location = \"http://localhost:8080/DisasterRlfApp/JSP/DisasterHomePage.jsp\";"
	                    + "</script></body></html>");  }
			
		}
		
		else
		
		{
			System.out.println("Query not executed");
			response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body><script>alert('Password reset was Not Successfull!');"
                    + "window.location = \"http://localhost:8080/DisasterRlfApp/JSP/ResetPasswd.jsp\";"
                    + "</script></body></html>");  }
		} 
		
		}
		
		
	}
		
	
	



