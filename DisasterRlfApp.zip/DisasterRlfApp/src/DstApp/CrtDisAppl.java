package DstApp;

public class CrtDisAppl {

	private String Appl_id;
	private String custName;
	private String stateName;
	private String cntyName;
	private String dstrType;
	private String cmdty;
	private String lossQty;
	private String uOM;
	private String claimAmt;
	private String aprvdAmt;
	private String appStatus;
	
	
 
	 public void set_Appl_id(String Appl_id) {
			this.Appl_id = Appl_id; 	}
	
	public int get_Appl_id() {
				
		int appl_Id =  Integer.parseInt(Appl_id.trim());
				System.out.println(appl_Id);
				 return appl_Id;}
	
    	public void set_custName(String custName) {
			this.custName = custName; 	}
	
	public String get_custName() {
		return custName; 	}
		
	public void set_stateName(String stateName) {
		this.stateName = stateName;	}
	
	public String get_stateName() {
		return stateName;	}
	
	public void set_cntyName(String cntyName) {
		this.cntyName = cntyName;	}
	
	public String get_cntyName() {
		return cntyName;	}
	
	public void set_dstrType(String dstrType) {
		this.dstrType = dstrType;	}
	
	public String get_dstrType( ) {
		return dstrType;	}
	
	public void set_cmdty(String cmdty) {
		this.cmdty = cmdty;	}
	
	public String get_cmdty( ) {
		return cmdty;	}
	 	
	
	public void set_lossQty(String lossQty) {
		this.lossQty = lossQty;	}
	
	public int get_lossQty() {
		int loss_quantity = Integer.parseInt(lossQty.trim());	
	    return loss_quantity; }
	
	public void set_uOM(String uOM ) {
		this.uOM = uOM;	}
	
	public String get_uOM() {
		return uOM;	}
	
	public void set_claimAmt(String claimAmt) {
		this.claimAmt = claimAmt;	}
	
	public double get_claimAmt( ) {
		double claim_amt = Double.parseDouble(claimAmt.trim());
		return claim_amt; }
	
	public void set_aprvdAmt(String aprvdAmt ) {
		this.aprvdAmt =aprvdAmt ;	}
	
	public int get_aprvdAmt( ) {
		 int approved_amt = Integer.parseInt(aprvdAmt.trim());
		 return approved_amt;}
	
		public void set_appStatus(String appStatus ) {
		this.appStatus =  appStatus;	}
		
		public String get_appStatus( ) {
			return appStatus;	}
		
	
	
}
