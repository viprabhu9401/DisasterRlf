package DstApp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



public class DisasterCreate {
	private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private String DstrName;
	private String DstrCode;
	private String Dstrtype;
	private String StateName;
	private String CountyName;
	private String startDate;
	private String endDate;
	
	
	public void set_DstrName(String DstrName) {
		this.DstrName = DstrName;
	}
	
	public String get_DstrName() {
		return DstrName;
	}
	
	public void set_DstrCode(String DstrCode) {
		this.DstrCode = DstrCode;
	}
	
	public int get_DstrCode() {
		int dst_code =  Integer.parseInt(DstrCode);
		return dst_code; 	}
		
	public void set_Dstrtype(String Dstrtype) {
		this.Dstrtype = Dstrtype;
	}
	
	public String get_Dstrtype() {
		return Dstrtype;}
	 
		
	public String get_State()
	{
		return StateName;
	}
	
	
	
	public void set_State(String StateName) {
		this.StateName = StateName;
	}
	
	public String get_Cnty()
	{
		return CountyName;
	}
	
	    public void  set_Cnty(String CountyName)
    {
    	this.CountyName = CountyName;
    }
	    
	public java.sql.Date get_startDte() throws ParseException
	{
		
		Date  start_date = simpleDateFormat.parse(startDate);
		//return java.sql.Date(start_date)
				return new java.sql.Date(start_date.getTime());
				//java.sql.Date(start_date.getDate()
		
		//return (new java.sql.Date(startDate.getTime()));
		//return startDate;
	}
	
	public void set_StrtDte(String startDate)
	{
		this.startDate = startDate;
	}
	
	public java.sql.Date get_endDte() throws ParseException
	{
		//return (new java.sql.Date(endDate.getTime()));
		System.out.println(endDate);
		Date end_date = simpleDateFormat.parse(endDate);
				System.out.println(end_date);
		//return end_date;
		System.out.println(new java.sql.Date(end_date.getTime()));
		return new java.sql.Date(end_date.getTime());
	}

	public void set_endtDte(String endDate)
	{
		this.endDate = endDate;
	}
	
	
}
