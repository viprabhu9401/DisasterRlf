package DstApp;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebFilter(filterName = "SessionFilter", urlPatterns = "/*")
public class SessionFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest request = (HttpServletRequest) req;
        PrintWriter out= resp.getWriter();

        String path = request.getRequestURI().substring(request.getContextPath().length());

        if (path.equals("/") || path.equals("/index.jsp") ||   path.equals("/css/styles.css") ||
              path.equals("/JSP/DisasterHomePage.jsp") || path.equals("/DisasterHome") || path.equals("/DisasterHomePage")|| path.equals("/JSP/ResetPasswd.jsp")||path.equals("/Resetpswdsrvlt")) {
            chain.doFilter(request, resp);
            return;
        } else {
            HttpSession httpSession = request.getSession();
            String name=(String)httpSession.getAttribute("name");
            if(name == null){
                out.print("Please login first");
                request.getRequestDispatcher("/index.jsp").forward(request, resp);
            }
        }

        chain.doFilter(request, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
